use anyhow::Result;
use rayon::prelude::*;
use solana_sdk::signer::keypair::Keypair;
use solana_sdk::signer::Signer;
use std::collections::HashSet;
use std::fs::{self, OpenOptions};
use std::io::Write;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};
use tokio::sync::mpsc;

const TARGETS_FILE: &str = "../targets.txt";
const FOUND_FILE: &str = "../found.txt";
const RPC_URL: &str = "https://solana-mainnet.api.syndica.io/api-key/BSjbDnjDjdi6yZc1Kb9e3AJCWA9b33GxSWQApPjUNWdq1YJiR62KWNhLxHaTUdqdLGzeZehbfGBfBJBvKkWnDz8XFmjetyAup7";

#[tokio::main]
async fn main() -> Result<()> {
    println!("Starting Solana Matcher (Rust Optimized)...");

    // 1. Load Targets
    let targets = load_targets(TARGETS_FILE)?;
    println!("Loaded {} targets from {}", targets.len(), TARGETS_FILE);
    
    // Shared state
    let targets = Arc::new(targets);
    let counter = Arc::new(AtomicU64::new(0));
    let found_count = Arc::new(AtomicU64::new(0));
    let running = Arc::new(AtomicBool::new(true));

    // Channel for async RPC checks
    let (tx, mut rx) = mpsc::channel::<(String, String)>(100);

    // 2. Spawn Status Printer
    let counter_clone = counter.clone();
    let found_clone = found_count.clone();
    let running_clone = running.clone();
    tokio::spawn(async move {
        let start = Instant::now();
        let mut last_count = 0;
        while running_clone.load(Ordering::Relaxed) {
            tokio::time::sleep(Duration::from_secs(1)).await;
            let total = counter_clone.load(Ordering::Relaxed);
            let found = found_clone.load(Ordering::Relaxed);
            let speed = total - last_count;
            last_count = total;
            let elapsed = start.elapsed().as_secs();
            
            print!(
                "\rChecked: {} | Found: {} | Speed: {} keys/sec | Time: {}s    ", 
                total, found, speed, elapsed
            );
            use std::io::Write;
            std::io::stdout().flush().unwrap();
        }
    });

    // 3. Spawn RPC Checker
    let found_clone2 = found_count.clone();
    tokio::spawn(async move {
        let client = reqwest::Client::new();
        while let Some((addr, priv_key)) = rx.recv().await {
            found_clone2.fetch_add(1, Ordering::Relaxed);
            println!("\n[MATCH FOUND] Address: {} | Priv: {}", addr, priv_key);
            
            // Log to file
            if let Ok(mut file) = OpenOptions::new().create(true).append(true).open(FOUND_FILE) {
                let _ = writeln!(file, "{},{},0.0", chrono::Local::now(), addr);
            }

            // Check Balance
            match check_balance(&client, &addr).await {
                Ok(bal) => {
                    println!(" -> Balance: {} SOL", bal);
                    // Update log with balance if needed (simple append for now)
                }
                Err(e) => println!(" -> Failed to check balance: {}", e),
            }
        }
    });

    // 4. Spawn Stats Reporter (new thread)
    let counter_stats_clone = counter.clone();
    let found_stats_clone = found_count.clone();
    let running_stats_clone = running.clone();
    tokio::spawn(async move {
        while running_stats_clone.load(Ordering::Relaxed) {
            tokio::time::sleep(Duration::from_secs(5)).await; // Report every 5 seconds
            let count = counter_stats_clone.load(Ordering::Relaxed);
            let found = found_stats_clone.load(Ordering::Relaxed);
            let elapsed = start_time.elapsed().as_secs_f64();
            let speed = if elapsed > 0.0 { count as f64 / elapsed } else { 0.0 };

            let stats = serde_json::json!({
                "checked": count,
                "speed_keys_per_sec": speed,
                "found": found,
                "uptime_seconds": elapsed
            });

            if let Ok(mut file) = OpenOptions::new().create(true).write(true).truncate(true).open(STATS_FILE) {
                let _ = writeln!(file, "{}", stats.to_string());
            }
        }
    });

    // 5. Main Generation Loop (Rayon)
    // We use a dedicated thread for the CPU-bound work so it doesn't block the Tokio runtime
    let targets_clone = targets.clone();
    let counter_clone2 = counter.clone();
    let tx_clone = tx.clone();
    
    // Inject test key logic (run once)
    {
        let injected_priv = "5CcxJCJJNXHhE3giPKatJA8Ppmorgi5KgiEnMpeHFQsChdRbnsbXrt6t4rtTJPTP2U9X614n8gmDcotLJbCtYP2K";
        let kp = Keypair::from_base58_string(injected_priv);
        let addr = kp.pubkey().to_string();
        if targets_clone.contains(&addr) {
             let _ = tx_clone.send((addr, injected_priv.to_string())).await;
        }
    }

    // Run CPU intensive task in a blocking thread
    tokio::task::spawn_blocking(move || {
        rayon::iter::repeat(()).for_each(|_| {
            let kp = Keypair::new();
            let addr = kp.pubkey().to_string();
            
            if targets_clone.contains(&addr) {
                let priv_key = kp.to_base58_string();
                // Blocking send is fine here as it's rare
                let _ = tx_clone.blocking_send((addr, priv_key));
            }
            
            counter_clone2.fetch_add(1, Ordering::Relaxed);
        });
    }).await?;

    Ok(())
}

fn load_targets(path: &str) -> Result<HashSet<String>> {
    let content = fs::read_to_string(path).unwrap_or_default();
    let mut set = HashSet::new();
    for line in content.lines() {
        let line = line.trim();
        if !line.is_empty() && !line.starts_with('#') {
            set.insert(line.to_string());
        }
    }
    Ok(set)
}

async fn check_balance(client: &reqwest::Client, addr: &str) -> Result<f64> {
    let body = serde_json::json!({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getBalance",
        "params": [addr, {"commitment": "confirmed"}]
    });

    let resp = client.post(RPC_URL)
        .json(&body)
        .send()
        .await?
        .json::<serde_json::Value>()
        .await?;

    if let Some(val) = resp.get("result").and_then(|r| r.get("value")).and_then(|v| v.as_u64()) {
        Ok(val as f64 / 1_000_000_000.0)
    } else {
        Ok(0.0)
    }
}
